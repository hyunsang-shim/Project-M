local C, F, L, OW = unpack(select(2, ...))
local ChatModule = OW:NewModule("Chat", "AceHook-3.0")

----------------------------------------------------------------
-- APIs
----------------------------------------------------------------

local min = math.min
local max = math.max
local format = string.format
local floor = math.floor
local sqrt = math.sqrt
local sin = math.sin
local asin = math.asin
local cos = math.cos
local acos = math.acos
local atan = math.atan
local rad = math.rad
local modf = math.modf

----------------------------------------------------------------
-- Skin
----------------------------------------------------------------

local backdrop = {
	bgFile = F.Media.."White",
	edgeFile = "",
	tile = true, tileSize = 16, edgeSize = 0,
	insets = {left = 0, right = 0, top = 0, bottom = 0}
}

local function HideTexture(f)
	f:SetTexture(nil)
	f.SetTexture = function() return end
end

local OldAddMessage = {}
local function AddMessage(self, text, ...)
	text = BetterDate("[%H:%M]", time()).." "..text
	return OldAddMessage[self](self, text, ...)
end

local function ChatSlider_SetValue(frame, slider)
	local range = frame: GetMaxScrollRange()
	local offset = frame: GetScrollOffset()
	local value = 1000*(range-offset)/range or 0
	slider: SetValue(0) --Debug
	if value < 0 then
		value = 0
	elseif value > 1000 then
		value = 1000
	end
	slider: SetValue(value)
end

local function ChatFrame_Skin(f)
	for _, frameName in pairs(CHAT_FRAMES) do
		local ChatFrame = _G[frameName]
		if not ChatFrame.styled then
            local Tab = _G[frameName.."Tab"]
            local EditBox = _G[frameName.."EditBox"]
            local i = ChatFrame:GetID()
			 
			for j = 1, #CHAT_FRAME_TEXTURES do
				_G[frameName..CHAT_FRAME_TEXTURES[j]]:SetTexture(nil)
			end
			
			if i and (i ~= 2) then
				--OldAddMessage[ChatFrame] = ChatFrame.Addmessage
				--ChatFrame.AddMessage = AddMessage
			end
			
			local ebParts = {"Left", "Mid", "Right", "Middle"}
			for _, ebParts in ipairs(ebParts) do
				if _G[frameName.."EditBox"..ebParts] then
					HideTexture(_G[frameName.."EditBox"..ebParts])
				end
				if _G[frameName.."EditBoxFocus"..ebParts] then
					HideTexture(_G[frameName.."EditBoxFocus"..ebParts])
				end
				if _G[frameName.."Tab"..ebParts] then
					HideTexture(_G[frameName.."Tab"..ebParts])
				end
				if _G[frameName.."TabHighlight"..ebParts] then
					HideTexture(_G[frameName.."TabHighlight"..ebParts])
				end
				if _G[frameName.."TabSelected"..ebParts] then
					HideTexture(_G[frameName.."TabSelected"..ebParts])
				end
			end
			
			F.HideFrame(_G[frameName.."ButtonFrame"])
			F.HideFrame(_G[frameName.."EditBoxLanguage"])
			
			ChatFrame: SetShadowColor(0,0,0)
			ChatFrame: SetShadowOffset(1,-1)
			ChatFrame: SetSpacing(1)
			
			Tab: SetClampedToScreen(true)
			Tab: SetAlpha(0)
			Tab.noMouseAlpha = 0
			--ChatFrame: SetFading(false)
			ChatFrame: SetClampedToScreen(false)
			
			local FrameBack = CreateFrame("Frame", nil, ChatFrame)
			FrameBack: SetFrameLevel(ChatFrame:GetFrameLevel()-1)
			FrameBack: SetPoint("TOPLEFT", ChatFrame, "TOPLEFT", -3,3)
			FrameBack: SetPoint("BOTTOMRIGHT", ChatFrame, "BOTTOMRIGHT", 1+26,-3)
			FrameBack: SetBackdrop(backdrop)
			FrameBack: SetBackdropColor(F.Color(C.Color.Black, 0.6))
			FrameBack: Hide()
			
			local FrameSlider = CreateFrame("Slider", frameName.."_Slider", ChatFrame)
			FrameSlider: SetFrameLevel(FrameBack:GetFrameLevel()+2)
			FrameSlider: SetOrientation("VERTICAL")
			FrameSlider: SetThumbTexture(F.Media.."Config_Slider", "ARTWORK")
			FrameSlider: SetWidth(18)
			FrameSlider: SetPoint("TOPRIGHT", FrameBack, "TOPRIGHT", -3,-8)
			FrameSlider: SetPoint("BOTTOMRIGHT", FrameBack, "BOTTOMRIGHT", -3,8)
			FrameSlider: SetMinMaxValues(0, 1000)
			--FrameSlider: SetValueStep(1)
			FrameSlider: SetValue(0)
			FrameSlider: Enable()
			FrameSlider: Hide()
			
			FrameSlider: SetScript("OnValueChanged", function(self)
				local maxRange = _G[frameName]: GetMaxScrollRange()
				local offset = floor(maxRange - (maxRange*self:GetValue()/1000) + 0.5)
				_G[frameName]: SetScrollOffset(offset)
			end)
			FrameSlider: SetScript("OnShow", function(self)
				ChatSlider_SetValue(ChatFrame, FrameSlider)
			end)
			ChatFrame: HookScript("OnEvent", function(self, event)
				if FrameSlider: IsShown() then
					ChatSlider_SetValue(_G[frameName], FrameSlider)
				end
			end)
			
			local FrameSliderHelp = CreateFrame("Frame", nil, ChatFrame)
			FrameSliderHelp: SetFrameLevel(FrameBack:GetFrameLevel()+1)
			FrameSliderHelp: SetPoint("TOPLEFT", FrameSlider, "TOPLEFT", -14, 30)
			FrameSliderHelp: SetPoint("BOTTOMRIGHT", FrameSlider, "BOTTOMRIGHT", 18, -30)
			
			FrameSliderHelp: SetScript("OnEnter", function(self)
				FrameSlider: Show()
				ChatSlider_SetValue(_G[frameName], FrameSlider)
			end)
			FrameSliderHelp: SetScript("OnLeave", function(self)
				if not (FrameSlider:IsMouseOver() or FrameBack:IsShown()) then
					FrameSlider: Hide()
				end
			end)
			FrameSlider: SetScript("OnLeave", function(self)
				if (not (FrameSlider:IsMouseOver() or FrameSliderHelp:IsMouseOver())) and FrameSliderHelp:IsShown() and (not FrameBack:IsShown()) then
					FrameSlider: Hide()
				end
			end)
			
			local FrameSliderBack = FrameSlider:CreateTexture(nil, "BACKGROUND")
			FrameSliderBack: SetTexture(F.Media.."White")
			FrameSliderBack: SetVertexColor(unpack(C.Color.White2))
			FrameSliderBack: SetWidth(6)
			FrameSliderBack: SetPoint("TOP", FrameSlider, "TOP", 0,0)
			FrameSliderBack: SetPoint("BOTTOM", FrameSlider, "BOTTOM", 0,0)
			FrameSliderBack: SetAlpha(0.4)
			
			local EditBoxBack = CreateFrame("Frame", nil, EditBox)
			EditBoxBack: SetFrameLevel(EditBox:GetFrameLevel()-1)
			EditBoxBack: SetPoint("TOPLEFT", EditBox, "TOPLEFT", 2, -4)
			EditBoxBack: SetPoint("BOTTOMRIGHT", EditBox, "BOTTOMRIGHT", -4+26, 4)
			EditBoxBack: SetBackdrop(backdrop)
			EditBoxBack: SetBackdropColor(F.Color(C.Color.Black, 0.6))
			EditBoxBack: Hide()
			
			local EditBoxBack_MenuButton = CreateFrame("Button", frameName.."EditBox_MenuButton", EditBoxBack)
			--EditBoxBack_MenuButton: SetFrameStrata("DIALOG")
			EditBoxBack_MenuButton: SetFrameLevel(EditBox:GetFrameLevel()+1)
			EditBoxBack_MenuButton: SetPoint("TOPLEFT", EditBoxBack, "TOPLEFT", 0,0)
			EditBoxBack_MenuButton: SetPoint("BOTTOMRIGHT", EditBoxBack, "BOTTOMLEFT", 44,0)
			EditBoxBack_MenuButton: RegisterForClicks("LeftButtonUp", "RightButtonUp")
			EditBoxBack_MenuButton: SetScript("OnClick", function(self, button)
				if ChatChannelSwitch then
					if ChatChannelSwitch: IsShown() then
						ChatChannelSwitch: Hide()
					else
						ChatChannelSwitch: SetPoint("BOTTOMLEFT", EditBoxBack_MenuButton, "TOPLEFT", 0,2)
						ChatChannelSwitch: Show()
					end
				end
			end)
			
			--local EditBox_Language = CreateFrame("Button", frameName.."EditBox_Language", EditBoxBack, "SecureActionButtonTemplate")
			local EditBox_Language = CreateFrame("Button", frameName.."EditBox_Language", EditBoxBack)
			EditBox_Language: SetFrameLevel(EditBox:GetFrameLevel()+1)
			EditBox_Language: SetPoint("TOPLEFT", EditBoxBack, "TOPRIGHT", -26, 0)
			EditBox_Language: SetPoint("BOTTOMRIGHT", EditBoxBack, "BOTTOMRIGHT", 0, 0)
			--EditBox_Language: SetNormalFontObject(DialogButtonNormalText)
			EditBox_Language: SetNormalFontObject(DialogButtonHighlightText)
			EditBox_Language: SetText(_G["INPUT_"..EditBox:GetInputLanguage()])
			--EditBox_Language: SetAttribute("type", "click")
			--EditBox_Language: SetAttribute("clickbutton", _G[frameName.."EditBoxLanguage"])
			EditBox_Language: SetScript("OnClick", function(self)
				EditBox: ToggleInputLanguage()
			end)
			
			local EditBox_LanguageBorder = EditBox_Language: CreateTexture(nil, "ARTWORK")
			EditBox_LanguageBorder: SetTexture(F.Media.."White")
			EditBox_LanguageBorder: SetVertexColor(unpack(C.Color.White))
			EditBox_LanguageBorder: SetAlpha(0.9)
			EditBox_LanguageBorder: SetPoint("TOPLEFT", EditBox_Language, "TOPLEFT", 0,-4)
			EditBox_LanguageBorder: SetPoint("BOTTOMRIGHT", EditBox_Language, "BOTTOMLEFT", 2,4)
			
			EditBox: Hide()
			EditBox: HookScript("OnEditFocusGained", function(self)
				--UIFrameFadeIn(EditBoxBack, 0.2, 0, 1)
				EditBoxBack: Show()
				FrameBack: Show()
				FrameSlider: Show()
				ChatSlider_SetValue(_G[frameName], FrameSlider)
				FrameSliderHelp: Hide()
				--EditBoxBack_MenuButton:Raise();
			end)
			EditBox: HookScript("OnEditFocusLost", function(self)
				--UIFrameFadeOut(EditBoxBack, 0.2, 1, 0)
				EditBoxBack: Hide()
				FrameBack: Hide()
				FrameSlider: Hide()
				FrameSliderHelp: Show()
				if ChatChannelSwitch then
					if ChatChannelSwitch: IsShown() then
						ChatChannelSwitch: Hide()
					end
				end
			end)
			EditBox: HookScript("OnInputLanguageChanged", function(self)
				local variable = _G["INPUT_"..self:GetInputLanguage()]
				EditBox_Language: SetText(variable)
			end)
			ChatFrame.styled = true
		end
	end
	
	CHAT_FRAME_TAB_NORMAL_NOMOUSE_ALPHA = 0
	CHAT_FRAME_TAB_SELECTED_NOMOUSE_ALPHA = 0
	--CHAT_TIMESTAMP_FORMAT = TIMESTAMP_FORMAT_HHMM_24HR
	F.HideFrame(ChatFrameMenuButton)
	F.HideFrame(QuickJoinToastButton)
	
	function ChatModule: Hook_OnMouseScroll(f, direct)
		for _, frameName in pairs(CHAT_FRAMES) do
			local ChatFrame = _G[frameName]
			local FrameSlider = _G[frameName.."_Slider"]
			if FrameSlider:IsShown() then
				local range = ChatFrame: GetMaxScrollRange()
				local offset = ChatFrame: GetScrollOffset()
				local value = floor(range - (range*FrameSlider:GetValue()/1000) + 0.5)
				if offset ~= value then
					FrameSlider: SetValue(1000*(range-offset)/range)
				end
			end
		end
	end
	ChatModule: SecureHook("FloatingChatFrame_OnMouseScroll", "Hook_OnMouseScroll")
end



local function ChatFrame_FontSize()
	--> 增加聊天栏字体大小选项
	for i = 1, 7 do
		CHAT_FONT_HEIGHTS[i] = i + 11
	end
end



----------------------------------------------------------------
-- EditBox Channel Button
----------------------------------------------------------------

local CHAT_CHANNEL = {
	--RAID_WARNING,
	{Text = SAY, Type = "SAY"},
	{Text = YELL, Type = "YELL"},
	{Text = EMOTE, Type = "EMOTE"},
	{Text = PARTY, Type = "PARTY"},
	{Text = RAID, Type = "RAID"},
	{Text = INSTANCE, Type = "INSTANCE_CHAT"},
	{Text = GUILD, Type = "GUILD"},
	{Text = OFFICER, Type = "OFFICER"},
}

local function ChatChannel_Switch(f)
	f.ChatSwitch = CreateFrame("Frame", "ChatChannelSwitch", f)
	f.ChatSwitch: SetSize(44,10)
	--f.ChatSwitch: SetPoint("BOTTOMLEFT", ChatFrame1EditBox, "TOPLEFT", 0,0)
	f.ChatSwitch: Hide()
	
	f.ChatSwitch.Channel = {}
	for i,v in ipairs(CHAT_CHANNEL) do
		f.ChatSwitch.Channel[i] = CreateFrame("Button", nil,f.ChatSwitch)
		f.ChatSwitch.Channel[i]: SetSize(44, 20)
		if i == 1 then
			f.ChatSwitch.Channel[i]: SetPoint("BOTTOM", f.ChatSwitch, "BOTTOM", 0,0)
		else
			f.ChatSwitch.Channel[i]: SetPoint("BOTTOM", f.ChatSwitch.Channel[i-1], "TOP", 0,0)
		end
		
		f.ChatSwitch.Channel[i]: SetBackdrop(backdrop)
		f.ChatSwitch.Channel[i]: SetBackdropColor(unpack(C.Color.Black))
		
		f.ChatSwitch.Channel[i].Text = F.create_Font(f.ChatSwitch.Channel[i], C.Font.Txt, 12, nil, 0)
		f.ChatSwitch.Channel[i].Text: SetPoint("CENTER")
		f.ChatSwitch.Channel[i].Text: SetText(v.Text)
		
		f.ChatSwitch.Channel[i]: RegisterForClicks("AnyUp")
		f.ChatSwitch.Channel[i]: SetScript("OnClick", function(self, button)
			for _, frameName in pairs(CHAT_FRAMES) do
				if _G[frameName.."EditBox"]:HasFocus() then
					_G[frameName.."EditBox"]:SetAttribute("chatType", v.Type)
					ChatEdit_UpdateHeader(_G[frameName.."EditBox"])
				end
			end
			f.ChatSwitch: Hide()
		end)
	end
end



local function Chat_Frame(f)
	ChatFrame_Skin(f)
	ChatFrame_FontSize(f)
	ChatChannel_Switch(f)
end

function F.ChatFrame_Load(f)
	Chat_Frame(f)
end

----------------------------------------------------------------

-- ScrollingMessageFrame:SetScrollOffset(offset)
-- ScrollingMessageFrame:GetScrollOffset()

-- ScrollingMessageFrame:GetMaxLines() - Get the maximum number of lines the frame can display.
-- ScrollingMessageFrame:GetMaxScrollRange()