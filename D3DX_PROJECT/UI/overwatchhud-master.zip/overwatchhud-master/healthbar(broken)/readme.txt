this was made by HaZe but I lost most of the files while moving my tf2 folder to a different hard drive.

here's whats left if you want to tinker with it. it doesn't work right now.